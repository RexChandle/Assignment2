import HttpRequest.HttpRequest;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.regex.*;
import java.io.File;
import java.io.FileOutputStream;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class Main2014302580331 {

	public static void main(String[] args) throws IOException {
		
		//��ҳ��ȡ
		String url = "http://staff.whu.edu.cn/show.jsp?lang=cn&n=Ai%20Xin%20Ping";
		HttpRequest get = HttpRequest.get(url); 
		String name = "Get2.html";     
		if(get.ok()){
			get.receive(new File(name));
		}
		
		//Jsoup����
		File input = new File("Get2.html");
		Document doc = Jsoup.parse(input, "UTF-8");                                                     
		Elements imfo1 = doc.select("div.col-md-10");       
		Elements imfo2 = doc.select("div.szll_wz");                                        
		//System.out.println(imfo1.text());
		String name1 = imfo1.select("h3").text();
		String telNumber = "";
		String mailAddr = "";
		
		//�绰����ƥ��
		Pattern p_tel = Pattern.compile("1[358][\\d]{9}");
		Matcher m_tel = p_tel.matcher(imfo1.text());
		if(m_tel.find())
		{
			telNumber = m_tel.group(0);
		}
		
		//����ƥ��
		String[] s = imfo1.text().split(" ");
		for(String s1:s)
		{
			Pattern p_mail = Pattern.compile("^\\s*\\w+(?:\\.{0,1}[\\w-]+)*@[a-zA-Z0-9]+(?:[-.][a-zA-Z0-9]+)*\\.[a-zA-Z]+\\s*$");
			Matcher m_mail = p_mail.matcher(s1);
			if(m_mail.find())
			{
				mailAddr = m_mail.group(0);
			}
		}
		
		//����txt�ļ�
		File file;
		FileOutputStream out = null;
		file = new File("result.txt");                                                
		out = new FileOutputStream(file);
        String imformation =name1+"\r\n"+telNumber+"\r\n"+mailAddr+"\r\n"+imfo2.text();             
	    if(!file.exists())                                                                        
		{
	    	file.createNewFile();
		}
		out.write(imformation.getBytes());                                                                
		out.flush();
		out.close();
	}
}

